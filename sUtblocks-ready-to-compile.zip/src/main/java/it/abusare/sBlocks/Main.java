package it.abusare.sBlocks;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.EnumSet;
import java.util.Set;

public class Main extends JavaPlugin implements Listener {
    private final Set<Material> blocchiSupportati = EnumSet.of(Material.WEB, Material.OBSIDIAN);

    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
    }

    @EventHandler
    public void quandoPiazza(BlockPlaceEvent e) {
        Block blocco = e.getBlock();
        Material tipo = blocco.getType();
        if (!blocchiSupportati.contains(tipo)) return;

        Location sopra = blocco.getLocation().add(0.5, 1.4, 0.5);
        ArmorStand timer = (ArmorStand) blocco.getWorld().spawnEntity(sopra, EntityType.ARMOR_STAND);
        timer.setVisible(false);
        timer.setGravity(false);
        timer.setMarker(true);
        timer.setCustomNameVisible(true);

        new BukkitRunnable() {
            int secondi = 10;
            public void run() {
                if (secondi <= 0) {
                    timer.remove();
                    if (blocco.getType() == tipo) blocco.setType(Material.AIR);
                    cancel();
                    return;
                }
                timer.setCustomName(ChatColor.RED.toString() + secondi);
                secondi--;
            }
        }.runTaskTimer(this, 0L, 20L);
    }
}